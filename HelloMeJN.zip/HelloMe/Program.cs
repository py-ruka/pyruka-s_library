﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloMe // - Jason Nguyen
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Set string variables
            string givenName; // Sets first string variable
            string lastName; // Sets last string variable


            // Requests two inputs of users first and last name
            Console.WriteLine("Hello! What is your first name? "); // Prints question for the first name
            givenName = Console.ReadLine(); // Requests User Input for firstName

            Console.WriteLine("What about your last name? "); // Prints question for the last name
            lastName = Console.ReadLine(); // Requests User Input for lastName

            // Displays user input (name) and prints best wishes.
            Console.WriteLine($"Nice to meet you, {givenName} {lastName}");
            Console.WriteLine("I hope you are well!");

            // Hints user the option to quit
            Console.WriteLine("Press any key to quit");
            Console.ReadKey();
        }
    }
}
