﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICTPRG302_Intro_to_Programming
{
    internal class Class1
    {
    }
}
