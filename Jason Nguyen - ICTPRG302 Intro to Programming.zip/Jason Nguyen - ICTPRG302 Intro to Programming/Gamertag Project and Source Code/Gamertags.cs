﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO; // Needed to access files

namespace ICTPRG302_Intro_to_Programming
{
    internal class Gamertags
    {
        // The list of gamertags loaded from file
        private string[] gamerTagList = { };

        public void LoadGamerTags()
        {
            gamerTagList = File.ReadAllLines("../Gamertags.txt");
        }

        // Gamertags Ending with a number
        public void PrintNumEndGamerTags()
        {
            Console.Clear();
            Console.WriteLine("=============================================");
            Console.WriteLine("Gamertags ENDING with a number");
            Console.WriteLine("=============================================");

            int lineNumber = 1;
            bool isRunning = true;

            // While isRunning is true, executes function
            while (isRunning)
            {
                // For each string from gamerTagList.txt
                foreach (string s in gamerTagList)
                {
                    // If the last character in a string is an integer, the statement will execute
                    if (char.IsDigit(s.Last()))
                    {
                        Console.WriteLine(lineNumber.ToString() + ") " + s);

                        lineNumber = lineNumber + 1;
                    }
                }

                // Requests user for key input to go back to the menu or exit program
                Console.WriteLine("\nWould you like to view the gamertags menu again?");
                if (Console.ReadKey().Key == ConsoleKey.Y)
                    ShowWelcomeMessage();
                else
                    isRunning = false;
            }
        }
        
        // Gamertags starting with NO letter or number
        public void PrintFilteredGamerTags()
        {
            Console.Clear();
            Console.WriteLine("=============================================");
            Console.WriteLine("Gamertags NOT starting with letter or number");
            Console.WriteLine("=============================================");

            int lineNumber = 1;
            bool isRunning = true;

            // While isRunning is true, executes function
            while (isRunning)
            {
                // For each string from gamerTagList.txt
                foreach (string s in gamerTagList)
                {
                    // Makes sure IF ganertag does NOT start with a letter AND number the statement passes and executes
                    if ((s.Length > 0) && Char.IsLetterOrDigit(s, 0) == false)
                    {
                        Console.WriteLine(lineNumber.ToString() + ") " + s);

                        lineNumber = lineNumber + 1;
                    }
                }

                // Requests user for key input to go back to the menu or exit program
                Console.WriteLine("\nWould you like to view the gamertags menu again?");
                if (Console.ReadKey().Key == ConsoleKey.Y)
                    ShowWelcomeMessage();
                else
                    isRunning = false;
            }
        }
        
        // Non-Filtered Gamertags
        public void PrintAllGamerTags()
        {
            Console.Clear();
            Console.WriteLine("=============================================");
            Console.WriteLine("All Gamertags");
            Console.WriteLine("=============================================");

            int lineNumber = 1;
            bool isRunning = true;

            // While isRunning is true, executes function.
            while (isRunning)
            {
                foreach (string s in gamerTagList)
                {
                    // Prints the current line number and gamer tag to the console
                    Console.WriteLine(lineNumber.ToString() + ") " + s);

                    // Increments the line number for the next itteration
                    lineNumber = lineNumber + 1;
                }

                // Requests user for key input to go back to the menu or exit program
                Console.WriteLine("\nWould you like to view the gamertags menu again?");
                if (Console.ReadKey().Key == ConsoleKey.Y)
                    ShowWelcomeMessage();
                else
                    isRunning = false;
            }
        }

        public void ShowWelcomeMessage()
        {
            // Displays Welcome Message
            Console.Clear();
            Console.WriteLine("=============================================");
            Console.WriteLine("Welcome to the Gamertag Database");
            Console.WriteLine("=============================================");

            // Requests user if they want to see filtered Gamertags or not
            Console.WriteLine("1: All Gamertags\n2: Gamertags Ending with a Number\n3: Gamertags NOT starting with letter or number");
            int FilterRequest = Convert.ToInt32(Console.ReadLine());
            
            // If user input is equal to a specified number, a function will be called
            if (FilterRequest == 1)
            {
                PrintAllGamerTags();
            }
            else if (FilterRequest == 2)
            {
                PrintNumEndGamerTags();
            }
            else if (FilterRequest == 3)
            {
                PrintFilteredGamerTags();
            }
        }
    }
}
