﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariablesTutJN
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Greets user, declares playerscore to 0 and displays the score insie a string var.
            string greeting = "Hello, user!";
            int playerScore = 0;
            string displayScore = $"Your score currently is {playerScore}.\n";

            // Dislays Current Dated Variables
            Console.WriteLine(greeting);
            Console.WriteLine(displayScore);
            Console.ReadKey();

            // Updates the Variables and displays the updated variables
            playerScore = 10;
            displayScore = $"Your score is now {playerScore}.\n";
            Console.WriteLine(displayScore);
            // Requests user for a value to update the player score then displays it
            Console.WriteLine("What do you want your score to be?");
            int playerUpdate = int.Parse(Console.ReadLine()); // Requests value
            playerScore = playerUpdate; // Sets playerScore to the same value as playerUpdate
            displayScore = $"You changed your score to {playerScore}!"; // Updated score message

            Console.WriteLine(displayScore);

            Console.WriteLine("\nPress enter to Exit!");
            Console.ReadKey();
        }
    }
}
